const userModel = require('../models/user.model');

showUserList = async (req, res) => {
    try {
        const [rows] = await userModel.getUsers();
        res.render('user/showUsers', { title: 'User', users: rows });
    } catch (err) {
        res.status(500).send('Database Error');
    }
};

showRegisterForm = (req, res) => {
    res.render('user/registerUser');
};

registerUser = async (req, res) => {
    const { firstName, lastName } = req.body;
    if (!firstName || !lastName) {
        return res.render('user/registerUser', { error: 'Bitte alle Felder ausfüllen.' });
    }

    try {
        await userModel.createUser(firstName, lastName);
        res.redirect('/user');
    } catch (err) {
        res.render('user/registerUser', { error: 'Fehler beim Speichern in der Datenbank.' });
    }
};

module.exports = {
    showUserList,
    showRegisterForm,
    registerUser,
};