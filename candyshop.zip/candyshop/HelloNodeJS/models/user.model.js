const pool = require('../config/db');

getUsers = async () => {
    const query = `SELECT id,
                        first_name,
                        last_name
                   FROM users_test
                   ORDER BY last_name, first_name`;
    const [result] = await pool.execute(query);

    return [result];
}

createUser = async (firstName, lastName) => {
    const query = `INSERT INTO users_test (first_name, last_name)
                   VALUES (?, ?)`;
    const values = [firstName, lastName];
    await pool.execute(query, values);
}

module.exports = {
    getUsers,
    createUser
}